===========UT3 Protocol FIX=====================================

....Version:
	v1.0 Final (well, it wasn't even necessary to release
	a Beta for this, so when any bugs appear, go to the
	Epic Forum, search for the Releasethread and post any
	issues there so i can release a working version.

....Author:
	Me ({GGMJ}Radon)
	mail: radon@ggmj.de

....Desc:
	This tool adds the missing protocol function of UT3.
	When Websites linked to ut2004://ip.adress.here:port,
	UT2004 was launched, connecting immediately to the
	Server which was linked in the url.
	
	With this fix, the same function comes back for ut3!
	So you can make use of the ut3:// protocol, with the
	same functionality of the ut2004 ones.
	
	Just place the included .exe file into your
	"./Unreal Tournament 3/Binaries/" Directory where the
	UT3.exe is located and run it one, to create the registry
	entrys to get it work.
	
	Each time you open a ut3:// link, the tool is launched,
	which redirects the informations to the UT3.exe, so you
	are immediately on your preferred server!
	
	The .exe file does not contain anything else such as
	spyware, virus, trojans, etc. It's just one registry
	entry, creating the protocol funtion and directing it
	to the UT3ProtocolFix.exe with the parameters, which
	are converted to a ut3-friendly format, then ut3 gets
	launched and the tool closes itself. nothing more.
	
	Thread @ utforums: http://forums.epicgames.com/showthread.php?t=605915
	
....Install:
	- Copy the UT3ProtocolFix.exe into your
      "./Unreal Tournament 3/Binaries/" Directory (UT3.exe is
      located there too)
    - Run the Application once and klick on "CREATE REGISTRY
      FIX" (Note: You have to do this, AFTER the app is moved
      into the UT3 Directory)
      ! for vista: If you have UAC active, you need to run
	  ! the program with administrationrights. To do that just
	  ! rightklick on the UT3ProtocolFix.exe and chose
	  ! "start as administrator"
    - Close the Tool

....Uninstall:
	To uninstall the registry entrys, just create a shortcut
	to the UT3ProtocolFix.exe, adding a "uninstall" parameter
	after the path. Example path for the UT3ProtocolFix.exe:
	"C:\Program Files\Unreal Tournament 3\Binaries\UT3ProtocolFix.exe" uninstall
	Note, that "uninstall" is not included in the Quotes!
	If the uninstall sequence was successfully, you'll get
	a message and after this, all registry entrys have been
	removed.
	
....Random Propaganda & Creditz
	radon.purgatory-labs.de <- Mah page! :D
	www.ggmj.de <- German UT3 Instagib Clan
	www.unrealed.info <- German Mapping Community
	Thx to {GGMJ}Stryke for Vista Testing!

....Legal Stuff:
	Use at your own Risk! When your PC gets damaged, ignites
	or explodes, i assume no liability for anything!

	Do not sell, put it on cd or use it otherwise for commercial
	use without asking me! Don't modify anything and don't
	publish it without this ReadMe!
	
================================================================	